package com.sparksfoundation.creditmanagementapp

import android.content.ContentValues
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.PersistableBundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.sparksfoundation.creditmanagementapp.EditUserActivity
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.getInstance
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.initializeInstance

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)

        supportActionBar?.hide()

        Handler().postDelayed({
            val intent = Intent(this@SplashScreen,ViewUsersActivity::class.java)
            startActivity(intent)
            finish()
        },3000)

    }
}
