package com.sparksfoundation.creditmanagementapp

import android.content.ContentValues
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.sparksfoundation.creditmanagementapp.EditUserActivity
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.getInstance
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.initializeInstance

class ViewUsersActivity : AppCompatActivity() {
    lateinit var addUserButton: Button
    lateinit var showTransactionsButton: Button
    lateinit var usersListView: ListView
    private var emptyView: View? = null
    private var mUserCursorAdapter: UserCursorAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_users)
        initializeInstance(DatabaseHelper(this))
        addUserButton = findViewById(R.id.add_user_button)
        addUserButton.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@ViewUsersActivity, EditUserActivity::class.java)
            startActivity(intent)
        })
        showTransactionsButton = findViewById(R.id.show_transactions_button)
        showTransactionsButton.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@ViewUsersActivity, TransactionsActivity::class.java)
            startActivity(intent)
        })
        usersListView = findViewById(R.id.users_list)
        emptyView = findViewById(R.id.empty_view)
        usersListView.setEmptyView(emptyView)
        mUserCursorAdapter = UserCursorAdapter(this, null)
        usersListView.setAdapter(mUserCursorAdapter)
        usersListView.setOnItemClickListener(OnItemClickListener { parent, view, position, id ->

                val builder = android.app.AlertDialog.Builder(this@ViewUsersActivity)
                builder.setTitle("What You Want To Do")

                builder.setPositiveButton("DELETE") { dialog, which ->
                    val dataFetchQuery = "SELECT * FROM " + DatabaseHelper.TABLE_USERS +
                            " WHERE " + DatabaseHelper.KEY_ID + " = " + id + ";"
                    getInstance()!!.openDatabase()
                    val cursor = getInstance()!!.getDetails(dataFetchQuery)
                    cursor.moveToFirst()
                    val userId = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_ID))
                    intent.putExtra(DatabaseHelper.KEY_ID, userId)
                    if (intent.extras != null) {
                        deleteUser(intent.getStringExtra(DatabaseHelper.KEY_ID).toInt())
                        val intent = Intent(this@ViewUsersActivity, ViewUsersActivity::class.java)
                        startActivity(intent)

                    }

                }
                builder.setNegativeButton("EDIT") { dialog, which ->

                    val intent = Intent(applicationContext, EditUserActivity::class.java)
                    val dataFetchQuery = "SELECT * FROM " + DatabaseHelper.TABLE_USERS +
                            " WHERE " + DatabaseHelper.KEY_ID + " = " + id + ";"
                    getInstance()!!.openDatabase()
                    val cursor = getInstance()!!.getDetails(dataFetchQuery)
                    cursor.moveToFirst()
                    val name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_NAME))
                    val email = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EMAIL))
                    val credits = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_CURRENT_CREDITS))
                    val userId = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_ID))
                    intent.putExtra(DatabaseHelper.KEY_NAME, name)
                    intent.putExtra(DatabaseHelper.KEY_EMAIL, email)
                    intent.putExtra(DatabaseHelper.KEY_CURRENT_CREDITS, credits)
                    intent.putExtra(DatabaseHelper.KEY_ID, userId)
                    startActivity(intent)
                }
                builder.show()



        })
        try {
            val dataFetchQuery = "SELECT * FROM " + DatabaseHelper.TABLE_USERS + ";"
            getInstance()!!.openDatabase()
            val cursor = getInstance()!!.getDetails(dataFetchQuery)
            if (cursor != null && cursor.count > 0) {
                showToast("No. of items :" + cursor.count)
            } else if (cursor.count == 0) {
                showToast("Add users to continue")
            }
            mUserCursorAdapter!!.swapCursor(cursor)
        } catch (e: Exception) {
            showToast("Catch Block, error in fetching data")
            Log.i("ViewUsersActivity", "Catch block error : ")
            e.printStackTrace()
        }
    }

    private fun deleteUser(id: Int) {
        val noOfRowsDeleted = getInstance()!!.delete(DatabaseHelper.TABLE_USERS, id)
        if (noOfRowsDeleted == 0) {
            // If no rows were affected, then there was an error with the update.
            Toast.makeText(this, "Delete Failed", Toast.LENGTH_SHORT).show()
        } else {
            // Otherwise, the update was successful and we can display a toast.
            Toast.makeText(this, "Delete Successful", Toast.LENGTH_SHORT).show()
        }
    }







    fun insertUser(name: String?, email: String?, credits: Int) {
        try {
            val values = ContentValues()
            values.put(DatabaseHelper.KEY_NAME, name)
            values.put(DatabaseHelper.KEY_EMAIL, email)
            values.put(DatabaseHelper.KEY_CURRENT_CREDITS, credits)
            getInstance()!!.openDatabase()
            getInstance()!!.insert(DatabaseHelper.TABLE_USERS, values)
        } catch (e: Exception) {
            showToast("Catch Block Executed, user not inserted")
            Log.i("ViewUsersActivity", "Catch block error here : ")
            e.printStackTrace()
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLongToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}