package com.sparksfoundation.creditmanagementapp.Classes

class Transaction {
    private var id = 0
    var sender: String? = null
    var receiver: String? = null
    var datetime: String? = null

    //constructor
    constructor() {}
    constructor(id: Int, sender: String?, receiver: String?, datetime: String?) {
        this.id = id
        this.sender = sender
        this.receiver = receiver
        this.datetime = datetime
    }

    //setters
    fun setId(id: Int) {
        this.id = id
    }

    //getters
    fun getId(): Long {
        return id.toLong()
    }

}