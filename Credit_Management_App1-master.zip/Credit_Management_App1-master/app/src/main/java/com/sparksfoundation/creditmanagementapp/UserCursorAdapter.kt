package com.sparksfoundation.creditmanagementapp

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper

class UserCursorAdapter(context: Context?, c: Cursor?) : CursorAdapter(context, c, 0) {
    override fun newView(context: Context, cursor: Cursor, parent: ViewGroup): View {
        return LayoutInflater.from(context).inflate(R.layout.user_item, parent, false)
    }

    override fun bindView(view: View, context: Context, cursor: Cursor) {
        val nameTextView = view.findViewById<TextView>(R.id.user_name)
        val emailTextView = view.findViewById<TextView>(R.id.user_email)
        val creditsTextView = view.findViewById<TextView>(R.id.credits)
        val transferButton = view.findViewById<ImageView>(R.id.transfer_button)
        val userId = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_ID))
        val name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_NAME))
        val email = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EMAIL))
        val credits = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_CURRENT_CREDITS))
        nameTextView.text = name
        creditsTextView.text = credits
        emailTextView.text = email
        transferButton.setOnClickListener {
            val intent = Intent(context, TransferUserSelectionActivity::class.java)
            intent.putExtra(DatabaseHelper.KEY_ID, userId)
            Toast.makeText(context, "Select the user to transfer credits to!", Toast.LENGTH_LONG).show()
            context.startActivity(intent)
        }
    }
}