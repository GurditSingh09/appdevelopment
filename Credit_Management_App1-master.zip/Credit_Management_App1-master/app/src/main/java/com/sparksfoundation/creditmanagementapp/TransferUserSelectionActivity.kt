package com.sparksfoundation.creditmanagementapp

import android.app.AlertDialog
import android.content.ContentValues
import android.content.DialogInterface
import android.os.Bundle
import android.support.v4.app.NavUtils
import android.support.v7.app.AppCompatActivity
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import android.widget.AdapterView.OnItemClickListener
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.getInstance
import java.text.SimpleDateFormat
import java.util.*

class TransferUserSelectionActivity : AppCompatActivity() {
    lateinit var receiverUsersListView: ListView
    private var mSendCreditsCursorAdapter: SendCreditsCursorAdapter? = null
    private var creditsToSendString: String? = null
    private var idReceiver = 0
    private var idSender = 0
    private var senderOpeningBalance = 0
    private var senderClosingBalance = 0
    private var receiverOpeningBalance = 0
    private var receiverClosingBalance = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transfer_user_selection)
        idSender = intent.getStringExtra(DatabaseHelper.KEY_ID).toInt()
        receiverUsersListView = findViewById(R.id.receiver_users_list)
        mSendCreditsCursorAdapter = SendCreditsCursorAdapter(this, null) //, senderId);
        receiverUsersListView.setAdapter(mSendCreditsCursorAdapter)
        try {
            val dataFetchQuery = "SELECT * FROM " + DatabaseHelper.TABLE_USERS + " WHERE " + DatabaseHelper.KEY_ID + " != " + idSender + ";"
            getInstance()!!.openDatabase()
            val cursor = getInstance()!!.getDetails(dataFetchQuery)
            mSendCreditsCursorAdapter!!.swapCursor(cursor)
        } catch (e: Exception) {
            showToast("Catch Block, error in fetching data")
            Log.i("TransferUserSelection", "Catch block error : ")
            e.printStackTrace()
        }
        receiverUsersListView.setOnItemClickListener(OnItemClickListener { adapterView, view, i, l ->
            idReceiver = l.toInt()
            showCreditDialog()
        })
    }

    fun showCreditDialog() {
        val builder = AlertDialog.Builder(this@TransferUserSelectionActivity)
        builder.setTitle("Transfer funds")
        builder.setMessage("Enter the amount you want to transfer")

        // Set up the input
        val input = EditText(applicationContext)

//        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
//        lp.setMargins(convertPixelsToDp(100,this), 0, convertPixelsToDp(100,this), 0);
//        input.setLayoutParams(lp);

        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.inputType = InputType.TYPE_CLASS_NUMBER // | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input)

        // Set up the buttons
        builder.setPositiveButton("SEND", DialogInterface.OnClickListener { dialog, which ->
            creditsToSendString = input.text.toString()
            if (TextUtils.isEmpty(creditsToSendString)) {
                Toast.makeText(applicationContext, "Please enter the number of credits to send", Toast.LENGTH_SHORT).show()
                return@OnClickListener
            }
            transferCredits()
        })
        builder.setNegativeButton("CANCEL") { dialog, which -> dialog.cancel() }
        builder.show()
    }

    fun transferCredits() {
        val senderDataFetchQuery = "SELECT " + DatabaseHelper.KEY_CURRENT_CREDITS + " FROM " + DatabaseHelper.TABLE_USERS + " WHERE " + DatabaseHelper.KEY_ID + " = " + idSender + ";"
        getInstance()!!.openDatabase()
        var cursor = getInstance()!!.getDetails(senderDataFetchQuery)
        cursor.moveToFirst()
        senderOpeningBalance = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_CURRENT_CREDITS))
        val receiverDataFetchQuery = "SELECT " + DatabaseHelper.KEY_CURRENT_CREDITS + " FROM " + DatabaseHelper.TABLE_USERS + " WHERE " + DatabaseHelper.KEY_ID + " = " + idReceiver + ";"
        getInstance()!!.openDatabase()
        cursor = getInstance()!!.getDetails(receiverDataFetchQuery)
        cursor.moveToFirst()
        receiverOpeningBalance = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_CURRENT_CREDITS))
        if (senderOpeningBalance - creditsToSendString!!.toInt() > 0) {
            senderClosingBalance = senderOpeningBalance - creditsToSendString!!.toInt()
            receiverClosingBalance = receiverOpeningBalance + creditsToSendString!!.toInt()
        } else {
            senderClosingBalance = senderOpeningBalance
            receiverClosingBalance = receiverOpeningBalance
            showToast("You don't have enough credits!")
            createTransaction("Failed")
            return
        }
        updateUser()
    }

    private fun updateUser() {
        val values = ContentValues()
        values.put(DatabaseHelper.KEY_CURRENT_CREDITS, senderClosingBalance)
        val noOfRowsUpdatedSender = getInstance()!!.update(DatabaseHelper.TABLE_USERS, values, idSender)
        values.put(DatabaseHelper.KEY_CURRENT_CREDITS, receiverClosingBalance)
        val noOfRowsUpdatedReceiver = getInstance()!!.update(DatabaseHelper.TABLE_USERS, values, idReceiver)

        // Show a toast message depending on whether or not the update was successful.
        if (noOfRowsUpdatedSender == 0 || noOfRowsUpdatedReceiver == 0) {
            // If no rows were affected, then there was an error with the update.
            showToast(getString(R.string.editor_update_user_failed))
        } else {
            // Otherwise, the update was successful and we can display a toast.
            showToast(getString(R.string.editor_update_user_successful))
            createTransaction("Success")
        }
        //        Intent intent = new Intent(TransferUserSelectionActivity.this, ViewUsersActivity.class);
//        finish();
//        startActivity(intent);
        NavUtils.navigateUpFromSameTask(this)
    }

    fun createTransaction(orderStatus: String?) {
        try {
            val values = ContentValues()
            values.put(DatabaseHelper.KEY_DATE_TIME, dateTime)
            values.put(DatabaseHelper.KEY_SENDER_ID, idSender)
            values.put(DatabaseHelper.KEY_RECEIVER_ID, idReceiver)
            values.put(DatabaseHelper.KEY_SENDER_OPENING_BALANCE, senderOpeningBalance)
            values.put(DatabaseHelper.KEY_SENDER_CLOSING_BALANCE, senderClosingBalance)
            values.put(DatabaseHelper.KEY_RECEIVER_OPENING_BALANCE, receiverOpeningBalance)
            values.put(DatabaseHelper.KEY_RECEIVER_CLOSING_BALANCE, receiverClosingBalance)
            values.put(DatabaseHelper.KEY_ORDER_STATUS, orderStatus)
            getInstance()!!.openDatabase()
            val inserted = getInstance()!!.insert(DatabaseHelper.TABLE_TRANSACTIONS, values)
            if (inserted) {
                showToast("Transaction created")
            } else {
                showToast("Transaction not created")
            }
        } catch (e: Exception) {
            showToast("Catch Block Executed, user not inserted")
            Log.i("EditUserActivity", "Catch block error here : ")
            e.printStackTrace()
        }
    }

    private val dateTime: String
        private get() {
            val dateFormat = SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val date = Date()
            return dateFormat.format(date)
        }

    //    public static int convertPixelsToDp(float px, Context context){
    //        Resources resources = context.getResources();
    //        DisplayMetrics metrics = resources.getDisplayMetrics();
    //        int dp = Math.round(px / (metrics.densityDpi / 160f));
    //        return dp;
    //    }
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLongToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}