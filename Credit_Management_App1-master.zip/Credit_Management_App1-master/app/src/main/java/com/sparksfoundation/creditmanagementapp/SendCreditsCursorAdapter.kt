package com.sparksfoundation.creditmanagementapp

import android.content.Context
import android.database.Cursor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CursorAdapter
import android.widget.TextView
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper

class SendCreditsCursorAdapter(context: Context?, c: Cursor?) : CursorAdapter(context, c, 0) {
    override fun newView(context: Context, cursor: Cursor, parent: ViewGroup): View {
        return LayoutInflater.from(context).inflate(R.layout.receiver_user_item, parent, false)
    }

    override fun bindView(view: View, context: Context, cursor: Cursor) {
        val nameTextView = view.findViewById<TextView>(R.id.user_name)
        val emailTextView = view.findViewById<TextView>(R.id.user_email)
        val name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_NAME))
        val email = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_EMAIL))
        nameTextView.text = name
        emailTextView.text = email
    }
}