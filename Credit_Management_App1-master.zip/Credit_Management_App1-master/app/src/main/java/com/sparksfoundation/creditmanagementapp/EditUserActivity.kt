package com.sparksfoundation.creditmanagementapp

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.NavUtils
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View.OnTouchListener
import android.widget.EditText
import android.widget.Toast
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.getInstance

class EditUserActivity : AppCompatActivity() {
    lateinit var mNameEditText: EditText
    lateinit var mEmailEditText: EditText
    lateinit var mCreditsEditText: EditText
    private val mDbHelper: DatabaseHelper? = null
    private var mUserHasChanged = false
    private val mTouchListener = OnTouchListener { view, motionEvent ->
        mUserHasChanged = true
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_user)
        mNameEditText = findViewById(R.id.edit_user_name)
        mEmailEditText = findViewById(R.id.edit_user_email)
        mCreditsEditText = findViewById(R.id.edit_user_credits)
        mNameEditText.setOnTouchListener(mTouchListener)
        mEmailEditText.setOnTouchListener(mTouchListener)
        mCreditsEditText.setOnTouchListener(mTouchListener)
        if (intent.extras != null) {
            supportActionBar!!.title = "Edit a user"
            val name = intent.getStringExtra(DatabaseHelper.KEY_NAME)
            val email = intent.getStringExtra(DatabaseHelper.KEY_EMAIL)
            val credits = intent.getStringExtra(DatabaseHelper.KEY_CURRENT_CREDITS)
            mNameEditText.setText(name)
            mEmailEditText.setText(email)
            mCreditsEditText.setText(credits)
        } else {
            supportActionBar!!.setTitle("Add a user")
        }
    }

    fun insertUser() {
        val name = mNameEditText!!.text.toString().trim { it <= ' ' }
        val email = mEmailEditText!!.text.toString().trim { it <= ' ' }
        var tempCredits = mCreditsEditText!!.text.toString().trim { it <= ' ' }
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "User not entered!", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        if (TextUtils.isEmpty(tempCredits)) {
            tempCredits = "0"
        }
        val credits = tempCredits.toInt()
        try {
            val values = ContentValues()
            values.put(DatabaseHelper.KEY_NAME, name)
            values.put(DatabaseHelper.KEY_EMAIL, email)
            values.put(DatabaseHelper.KEY_CURRENT_CREDITS, credits)
            getInstance()!!.openDatabase()
            val inserted = getInstance()!!.insert(DatabaseHelper.TABLE_USERS, values)
            if (inserted) {
                showToast("User Inserted")
            } else {
                showToast("Not inserted")
            }
        } catch (e: Exception) {
            showToast("Catch Block Executed, user not inserted")
            Log.i("EditUserActivity", "Catch block error here : ")
            e.printStackTrace()
        }
    }

    private fun updateUser(id: Int) {
        val name = mNameEditText!!.text.toString().trim { it <= ' ' }
        val email = mEmailEditText!!.text.toString().trim { it <= ' ' }
        var tempCredits = mCreditsEditText!!.text.toString().trim { it <= ' ' }
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, R.string.user_not_entered, Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        if (TextUtils.isEmpty(tempCredits)) {
            tempCredits = "0"
        }
        val credits = tempCredits.toInt()
        val values = ContentValues()
        values.put(DatabaseHelper.KEY_NAME, name)
        values.put(DatabaseHelper.KEY_EMAIL, email)
        values.put(DatabaseHelper.KEY_CURRENT_CREDITS, credits)
        val noOfRowsUpdated = getInstance()!!.update(DatabaseHelper.TABLE_USERS, values, id)

        // Show a toast message depending on whether or not the update was successful.
        if (noOfRowsUpdated == 0) {
            // If no rows were affected, then there was an error with the update.
            showToast(getString(R.string.editor_update_user_failed))
        } else {
            // Otherwise, the update was successful and we can display a toast.
            showToast(getString(R.string.editor_update_user_successful))
        }
    }



    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu options from the res/menu/menu_add_user.xml file.
        // This adds menu items to the app bar.
        menuInflater.inflate(R.menu.menu_add_user, menu)
        if (intent.extras == null) invalidateOptionsMenu()
        return true
    }



    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // User clicked on a menu option in the app bar overflow menu
        when (item.itemId) {
            R.id.action_save -> {
                if (intent.extras == null) {
                    insertUser()
                    //                    Intent intent = new Intent(EditUserActivity.this, ViewUsersActivity.class);
//                    finish();
//                    startActivity(intent);
                    NavUtils.navigateUpFromSameTask(this)
                } else {
                    updateUser(intent.getStringExtra(DatabaseHelper.KEY_ID).toInt())
                    //                    Intent intent = new Intent(EditUserActivity.this, ViewUsersActivity.class);
//                    finish();
//                    startActivity(intent);
                    NavUtils.navigateUpFromSameTask(this)
                }
                return true
            }

            android.R.id.home -> {
                if (mUserHasChanged) {
                    val alertDialog = AlertDialog.Builder(this@EditUserActivity).create()
                    alertDialog.setMessage("Discard your changes and quit editing?")
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Discard"
                    ) { dialog, which ->
                        dialog.dismiss()
                        // Navigate back to parent activity (MainActivity)
                        NavUtils.navigateUpFromSameTask(this@EditUserActivity)
                    }
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Keep Editing"
                    ) { dialog, which -> dialog.dismiss() }
                    alertDialog.show()
                } else  // Navigate back to parent activity (MainActivity)
                    NavUtils.navigateUpFromSameTask(this@EditUserActivity)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLongToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val LOG_TAG = "EditUserActivity"
    }
}