package com.sparksfoundation.creditmanagementapp.Helper

import android.content.ContentValues
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.util.concurrent.atomic.AtomicInteger

class DatabaseManager {
    private val mOpenCounter = AtomicInteger()
    private var mDatabase: SQLiteDatabase? = null

    @Synchronized
    fun openDatabase() {
        if (mOpenCounter.incrementAndGet() == 1) {
            mDatabase = mDatabaseHelper!!.writableDatabase
        }
    }

    @Synchronized
    fun closeDatabase() {
        if (mOpenCounter.decrementAndGet() == 0) {
            mDatabase!!.close()
        }
    }

    fun getDetails(query: String?): Cursor {
        return mDatabase!!.rawQuery(query, null)
    }

    fun insert(tableName: String?, values: ContentValues?): Boolean {
        var l: Long = -1
        try {
            l = mDatabase!!.insert(tableName, null, values)
            Log.i("DatabaseManager", "Insert Working in the DatabaseManager class")
        } catch (e: SQLException) {
            Log.i("DatabaseManager", "Insert Not working in the DatabaseManager class")
            e.printStackTrace()
        }
        return l != -1L
    }

    fun update(tableName: String?, values: ContentValues?, id: Int): Int {
        var l = 0
        try {
            l = mDatabase!!.update(tableName, values, DatabaseHelper.KEY_ID + " = " + id, null)
            Log.i("DatabaseManager", "Update Working in the DatabaseManager class")
        } catch (e: SQLException) {
            Log.i("DatabaseManager", "Update Not working in the DatabaseManager class")
            e.printStackTrace()
        }
        return l
    }

    fun delete(tableName: String?, id: Int): Int {
        var l = 0
        try {
            l = mDatabase!!.delete(tableName, DatabaseHelper.KEY_ID + " = " + id, null)
            Log.i("DatabaseManager", "Delete Working in the DatabaseManager class")
        } catch (e: SQLException) {
            Log.i("DatabaseManager", "Delete Not working in the DatabaseManager class")
            e.printStackTrace()
        }
        return l
    }

    fun deleteAll(tableName: String?): Int {
        var l = 0
        try {
            l = mDatabase!!.delete(tableName, null, null)
            Log.i("DatabaseManager", "Delete All Working in the DatabaseManager class")
        } catch (e: SQLException) {
            Log.i("DatabaseManager", "Delete All Not working in the DatabaseManager class")
            e.printStackTrace()
        }
        return l
    }

    fun deleteTable(tableName: String?): Boolean {
        try {
            mDatabase!!.delete(tableName, null, null)
        } catch (e: SQLException) {
            e.printStackTrace()
        }
        return true
    }

    companion object {
        private var instance: DatabaseManager? = null
        private var mDatabaseHelper: SQLiteOpenHelper? = null

        @JvmStatic
        @Synchronized
        fun initializeInstance(sqLiteOpenHelper: SQLiteOpenHelper?) {
            if (instance == null) {
                instance = DatabaseManager()
                mDatabaseHelper = sqLiteOpenHelper
            }
        }

        @JvmStatic
        @Synchronized
        fun getInstance(): DatabaseManager? {
            checkNotNull(instance) {
                DatabaseManager::class.java.simpleName +
                        " is not initialized, call initializeInstance() first."
            }
            return instance
        }
    }
}